DROP POLICY "Anyone can submit a contact message" ON public.contact_submissions;
CREATE POLICY "Anyone can submit a valid contact message" ON public.contact_submissions
FOR INSERT WITH CHECK (
  char_length(btrim(name)) BETWEEN 1 AND 100
  AND char_length(email) BETWEEN 3 AND 255
  AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'
  AND char_length(btrim(message)) BETWEEN 1 AND 2000
);