import { useState } from "react";
import { motion } from "framer-motion";
import { z } from "zod";
import { Linkedin, Send, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name must be under 100 characters"),
  email: z.string().trim().email("Please enter a valid email").max(255),
  message: z.string().trim().min(1, "Message is required").max(2000, "Message must be under 2000 characters"),
});

export function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = contactSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      for (const issue of result.error.issues) {
        fieldErrors[issue.path[0] as string] = issue.message;
      }
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    setStatus("sending");

    const { error } = await supabase.from("contact_submissions").insert(result.data);
    if (error) {
      console.error("Contact submission failed:", error.message);
      setStatus("error");
    } else {
      setStatus("sent");
      setForm({ name: "", email: "", message: "" });
    }
  };

  const inputClass =
    "w-full rounded-md border border-input bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition-colors focus:border-primary focus:ring-1 focus:ring-primary";

  return (
    <section id="contact" className="relative py-24 md:py-32">
      <div className="mx-auto grid max-w-6xl gap-14 px-5 md:px-8 lg:grid-cols-2 lg:gap-20">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Contact</p>
          <h2 className="mt-4 text-3xl font-semibold md:text-5xl">
            Let's <span className="text-gradient-gold italic">Collaborate</span>
          </h2>
          <p className="mt-6 max-w-md leading-relaxed text-muted-foreground">
            Whether you're launching a single listing or building a full property brand, we'd love to hear about it.
            Tell us about your project and we'll get back to you&nbsp; within 24 hours.
          </p>

          <a
            href="https://www.linkedin.com/company/shape-alchemy"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-3 rounded-md border border-border bg-card px-5 py-3 text-sm font-medium transition-all hover:border-primary/40 hover:text-primary"
          >
            <Linkedin className="h-4 w-4" />
            Connect on LinkedIn
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, delay: 0.1 }}
        >
          {status === "sent" ? (
            <div className="flex h-full flex-col items-center justify-center rounded-xl border border-primary/30 bg-card p-10 text-center shadow-card-elevated">
              <CheckCircle2 className="h-12 w-12 text-primary" strokeWidth={1.5} />
              <h3 className="mt-4 text-2xl font-semibold">Message Sent</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Thank you for reaching out. We'll reply within 24 hours.
              </p>
              <button
                onClick={() => setStatus("idle")}
                className="mt-6 text-sm font-medium text-primary underline-offset-4 hover:underline"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="rounded-xl border border-border bg-card p-8 shadow-card-elevated"
              noValidate
            >
              <div className="space-y-5">
                <div>
                  <label htmlFor="name" className="mb-2 block text-sm font-medium">
                    Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Your name"
                    className={inputClass}
                  />
                  {errors.name && <p className="mt-1.5 text-xs text-destructive">{errors.name}</p>}
                </div>
                <div>
                  <label htmlFor="email" className="mb-2 block text-sm font-medium">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="you@company.com"
                    className={inputClass}
                  />
                  {errors.email && <p className="mt-1.5 text-xs text-destructive">{errors.email}</p>}
                </div>
                <div>
                  <label htmlFor="message" className="mb-2 block text-sm font-medium">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Tell us about your project…"
                    className={`${inputClass} resize-none`}
                  />
                  {errors.message && <p className="mt-1.5 text-xs text-destructive">{errors.message}</p>}
                </div>

                {status === "error" && (
                  <p className="text-sm text-destructive">Something went wrong. Please try again.</p>
                )}

                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-6 py-3.5 text-sm font-semibold uppercase tracking-wider text-primary-foreground transition-all hover:shadow-gold-glow hover:brightness-110 disabled:opacity-60"
                >
                  {status === "sending" ? "Sending…" : "Send"}
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </section>
  );
}
