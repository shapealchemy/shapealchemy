export function Footer() {
  return (
    <footer className="border-t border-border py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 md:flex-row md:px-8">
        <p className="font-display text-lg font-semibold">
          Shape<span className="text-gradient-gold"> Alchemy</span>
        </p>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Shape Alchemy. Visualizing the future of real estate.
        </p>
      </div>
    </footer>
  );
}
