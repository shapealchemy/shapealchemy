import { motion } from "framer-motion";

const particles = [
  { left: "12%", top: "22%", size: 4, delay: 0 },
  { left: "24%", top: "68%", size: 3, delay: 1.2 },
  { left: "38%", top: "34%", size: 5, delay: 0.6 },
  { left: "55%", top: "18%", size: 3, delay: 2 },
  { left: "68%", top: "60%", size: 4, delay: 0.9 },
  { left: "80%", top: "30%", size: 5, delay: 1.6 },
  { left: "88%", top: "72%", size: 3, delay: 0.3 },
  { left: "45%", top: "78%", size: 4, delay: 2.4 },
];

export function Hero() {
  return (
    <section id="top" className="relative flex min-h-screen items-center justify-center overflow-hidden bg-hero-glow">
      <div className="grid-pattern absolute inset-0" aria-hidden="true" />

      {particles.map((p, i) => (
        <motion.span
          key={i}
          aria-hidden="true"
          className="absolute rounded-full bg-primary/60"
          style={{ left: p.left, top: p.top, width: p.size, height: p.size }}
          animate={{ y: [0, -24, 0], opacity: [0.2, 0.8, 0.2] }}
          transition={{ duration: 6, repeat: Infinity, delay: p.delay, ease: "easeInOut" }}
        />
      ))}

      <div className="relative z-10 mx-auto max-w-4xl px-5 pb-24 pt-32 text-center md:px-8">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="mb-6 inline-block rounded-full border border-primary/30 bg-primary/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary"
        >
          Real Estate Design Studio
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="text-4xl font-semibold leading-tight md:text-6xl lg:text-7xl"
        >
          Visualizing the Future of <span className="text-gradient-gold italic">Real Estate</span>.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mx-auto mt-6 max-w-2xl text-base text-muted-foreground md:text-lg"
        >
          Real Estate Graphic Design&ensp;|&ensp;Motion Graphics&ensp;|&ensp;Photo Upscaling
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.45 }}
          className="mt-10"
        >
          <a
            href="#contact"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-8 py-4 text-sm font-semibold uppercase tracking-wider text-primary-foreground transition-all hover:shadow-gold-glow hover:brightness-110"
          >
            Get a Free Quote
            <span aria-hidden="true">→</span>
          </a>
        </motion.div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" aria-hidden="true" />
    </section>
  );
}
