import { motion } from "framer-motion";
import mockupResidential from "@/assets/mockup-residential.jpg";
import mockupCommercial from "@/assets/mockup-commercial.jpg";
import mockupMotion from "@/assets/mockup-motion.jpg";
import mockupUpscale from "@/assets/mockup-upscale.jpg";
import mockupLand from "@/assets/mockup-land.jpg";
import mockupSocial from "@/assets/mockup-social.jpg";
import houseForRentFlyer from "@/assets/house-for-rent-flyer.png.asset.json";
import landPlotFlyer from "@/assets/land-plot-flyer.png.asset.json";

const previews = [
  { image: houseForRentFlyer.url, title: "Residential Concept", category: "Flyer & Brochure", w: 768, h: 1024 },
  { image: mockupCommercial, title: "Commercial Layout", category: "Presentation Design", w: 1024, h: 768 },
  { image: mockupMotion, title: "Social Animation", category: "Motion Graphics", w: 768, h: 1024 },
  { image: landPlotFlyer.url, title: "Land Plot Study", category: "Cartographic Design", w: 1024, h: 768 },
  { image: mockupSocial, title: "Story Template", category: "Social Media Kit", w: 768, h: 1024 },
  { image: mockupUpscale, title: "Resolution Alchemy", category: "AI Photo Upscaling", w: 1024, h: 768 },
];

export function Showcase() {
  return (
    <section id="work" className="relative bg-surface py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">Our Work</p>
          <h2 className="mt-4 text-3xl font-semibold md:text-5xl">
            Style <span className="text-gradient-gold italic">Previews</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            A glimpse of the visual language we bring to every project. Full case studies are in the making.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {previews.map((p, i) => (
            <motion.figure
              key={p.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: (i % 3) * 0.12 }}
              className="group relative overflow-hidden rounded-xl border border-border bg-card shadow-card-elevated"
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={p.image}
                  alt={`${p.title} — work-in-progress style preview`}
                  loading="lazy"
                  width={p.w}
                  height={p.h}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/20 to-transparent" />

                {/* Coming Soon badge removed */}

              </div>

              <figcaption className="absolute inset-x-0 bottom-0 p-6">
                <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-primary">{p.category}</p>
                <h3 className="mt-1 font-display text-xl font-semibold">{p.title}</h3>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
