import { motion } from "framer-motion";
import { Home, Building2, Clapperboard, Sparkles } from "lucide-react";

const services = [
  {
    icon: Home,
    title: "Residential Design",
    description:
      "High-end flyers and brochures for houses and apartments — crafted to make every listing feel like a landmark.",
  },
  {
    icon: Building2,
    title: "Commercial & Land Design",
    description:
      "Professional presentations for commercial properties and land plots that speak the language of investors.",
  },
  {
    icon: Clapperboard,
    title: "Motion Graphics & Reels",
    description:
      "Animated flyers and Instagram Reels optimized for social media engagement — designed to stop the scroll.",
  },
  {
    icon: Sparkles,
    title: "Photo Upscaling",
    description:
      "Enhancing image resolution and quality for print and digital media. Crisp, gallery-grade results every time.",
  },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="mx-auto max-w-2xl text-center"
        >
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">What We Do</p>
          <h2 className="mt-4 text-3xl font-semibold md:text-5xl">
            A Catalog of <span className="text-gradient-gold italic">Capabilities</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            From print-ready brochures to scroll-stopping motion — everything a modern property brand needs.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2">
          {services.map((s, i) => (
            <motion.article
              key={s.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group rounded-xl border border-border bg-card p-8 shadow-card-elevated transition-all hover:border-primary/40 hover:shadow-gold-glow"
            >
              <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-lg border border-primary/30 bg-primary/10 text-primary transition-transform group-hover:scale-110">
                <s.icon className="h-6 w-6" strokeWidth={1.5} />
              </div>
              <h3 className="text-xl font-semibold">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.description}</p>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
